import React from "react";

function NavbarGap(props) {
  return <div className="__navbarGap"></div>;
}

export default NavbarGap;
