import React from "react";

function CustomSimulation(props) {
  return <div className="__CustomSimulation">To be completed</div>;
}

export default CustomSimulation;
